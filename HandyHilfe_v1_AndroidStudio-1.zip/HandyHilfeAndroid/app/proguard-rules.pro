# HandyHilfe v1.0 - no shrinking rules needed for the MVP.
