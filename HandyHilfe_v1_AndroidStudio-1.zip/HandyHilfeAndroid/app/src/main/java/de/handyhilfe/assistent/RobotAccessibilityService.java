package de.handyhilfe.assistent;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;

public class RobotAccessibilityService extends AccessibilityService implements TextToSpeech.OnInitListener {
    public static final String ACTION_STOP_GUIDE = "de.handyhilfe.assistent.STOP_GUIDE";

    private WindowManager windowManager;
    private GuideOverlayView overlay;
    private TextToSpeech tts;
    private String lastSpokenStep = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean receiverRegistered = false;

    private final BroadcastReceiver stopReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (ACTION_STOP_GUIDE.equals(intent.getAction())) {
                AssistantState.stop(RobotAccessibilityService.this);
                if (overlay != null) overlay.hideGuide();
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        tts = new TextToSpeech(this, this);
        createOverlay();
        IntentFilter filter = new IntentFilter(ACTION_STOP_GUIDE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stopReceiver, filter, RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stopReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void createOverlay() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        overlay = new GuideOverlayView(this);
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        try {
            windowManager.addView(overlay, params);
        } catch (Exception ignored) {}
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || overlay == null) return;
        if (!AssistantState.isActive(this)) {
            overlay.hideGuide();
            return;
        }

        String expectedPackage = AssistantState.getExpectedPackage(this);
        String currentPackage = event.getPackageName() == null ? "" : event.getPackageName().toString();
        if (TextUtils.isEmpty(expectedPackage) && !TextUtils.isEmpty(currentPackage) && !getPackageName().equals(currentPackage)) {
            AssistantState.setExpectedPackage(this, currentPackage);
            expectedPackage = currentPackage;
        }
        if (!TextUtils.isEmpty(expectedPackage)
                && !expectedPackage.equals(currentPackage)
                && !getPackageName().equals(currentPackage)) {
            overlay.hideGuide();
            return;
        }

        String workflow = AssistantState.getWorkflow(this);
        int stepIndex = AssistantState.getStep(this);
        List<GuideStep> steps = WorkflowSpec.steps(workflow);
        GuideStep step = WorkflowSpec.current(workflow, stepIndex);
        if (step == null) {
            finishWorkflow(workflow);
            return;
        }

        AccessibilityNodeInfo source = event.getSource();
        int eventType = event.getEventType();
        if (source != null && shouldAdvanceFromEvent(source, step, eventType)) {
            AssistantState.advance(this);
            int newIndex = AssistantState.getStep(this);
            if (newIndex >= steps.size()) {
                finishWorkflow(workflow);
                return;
            }
            handler.postDelayed(this::refreshCurrentTarget, 550);
            return;
        }

        refreshCurrentTarget();
    }

    private void refreshCurrentTarget() {
        if (!AssistantState.isActive(this) || overlay == null) return;
        String workflow = AssistantState.getWorkflow(this);
        int stepIndex = AssistantState.getStep(this);
        GuideStep step = WorkflowSpec.current(workflow, stepIndex);
        if (step == null) {
            finishWorkflow(workflow);
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        AccessibilityNodeInfo best = findBestMatch(root, step);
        if (best == null) {
            overlay.hideGuide();
            return;
        }

        Rect bounds = new Rect();
        best.getBoundsInScreen(bounds);
        if (bounds.width() < 3 || bounds.height() < 3) {
            overlay.hideGuide();
            return;
        }

        int total = WorkflowSpec.steps(workflow).size();
        overlay.showTarget(bounds, step.instruction, "Schritt " + (stepIndex + 1) + " von " + total);
        if (!step.id.equals(lastSpokenStep)) {
            lastSpokenStep = step.id;
            speak(step.instruction);
        }
    }

    private boolean shouldAdvanceFromEvent(AccessibilityNodeInfo source, GuideStep step, int eventType) {
        if (source == null || source.isPassword()) return false;
        boolean matches = matchesNodeOrParents(source, step, 2);
        if (!matches) return false;

        if (GuideStep.TYPE_INPUT.equals(step.type) && eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
            CharSequence text = source.getText();
            String value = text == null ? "" : text.toString().trim();
            return value.length() >= step.minChars;
        }
        if ((GuideStep.TYPE_ACTION.equals(step.type) || GuideStep.TYPE_SWITCH.equals(step.type))
                && eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            return true;
        }
        return false;
    }

    private boolean matchesNodeOrParents(AccessibilityNodeInfo node, GuideStep step, int maxParents) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; current != null && i <= maxParents; i++) {
            if (scoreNode(current, step) > 0) return true;
            current = current.getParent();
        }
        return false;
    }

    private AccessibilityNodeInfo findBestMatch(AccessibilityNodeInfo root, GuideStep step) {
        Match best = new Match();
        walk(root, step, best, 0);
        return best.node;
    }

    private void walk(AccessibilityNodeInfo node, GuideStep step, Match best, int depth) {
        if (node == null || depth > 40) return;
        int score = scoreNode(node, step);
        if (score > best.score) {
            Rect r = new Rect();
            node.getBoundsInScreen(r);
            if (r.width() > 2 && r.height() > 2 && node.isVisibleToUser()) {
                best.score = score;
                best.node = node;
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) walk(child, step, best, depth + 1);
        }
    }

    private int scoreNode(AccessibilityNodeInfo node, GuideStep step) {
        if (node == null || node.isPassword() || !node.isVisibleToUser()) return 0;
        String text = normalize(node.getText());
        String desc = normalize(node.getContentDescription());
        String hint = Build.VERSION.SDK_INT >= 26 ? normalize(node.getHintText()) : "";
        String id = normalize(node.getViewIdResourceName());
        String cls = normalize(node.getClassName());
        String combined = text + " " + desc + " " + hint + " " + id;

        int best = 0;
        for (String raw : step.candidates) {
            String candidate = normalize(raw);
            if (candidate.isEmpty()) continue;
            if (candidate.length() == 1) {
                if (text.equals(candidate) || desc.equals(candidate)) best = Math.max(best, 85);
            } else {
                if (text.equals(candidate) || desc.equals(candidate) || hint.equals(candidate)) best = Math.max(best, 120);
                else if (combined.contains(candidate)) best = Math.max(best, 75);
            }
        }
        if (best == 0) return 0;

        if (GuideStep.TYPE_INPUT.equals(step.type)) {
            if (cls.contains("edittext") || node.isEditable()) best += 100;
            else best -= 30;
        } else if (GuideStep.TYPE_SWITCH.equals(step.type)) {
            if (cls.contains("switch") || cls.contains("checkbox") || node.isCheckable()) best += 110;
            if (node.isClickable()) best += 15;
        } else {
            if (node.isClickable()) best += 35;
            if (cls.contains("button")) best += 25;
        }
        return Math.max(0, best);
    }

    private void finishWorkflow(String workflow) {
        AssistantState.stop(this);
        lastSpokenStep = "";
        String message;
        switch (workflow) {
            case WorkflowSpec.CONTACT: message = "Geschafft! Der Kontakt ist gespeichert."; break;
            case WorkflowSpec.CAMERA: message = "Geschafft! Das Foto wurde aufgenommen."; break;
            case WorkflowSpec.ALARM: message = "Geschafft! Der Wecker ist eingestellt."; break;
            case WorkflowSpec.SMS: message = "Geschafft! Die Nachricht wurde gesendet."; break;
            case WorkflowSpec.WHATSAPP: message = "Gut. Jetzt kannst du die gewünschte Person auswählen."; break;
            default: message = "Geschafft!";
        }
        if (overlay != null) overlay.showSuccess(message);
        speak(message);
        handler.postDelayed(() -> {
            if (overlay != null) overlay.hideGuide();
        }, 2600);
    }

    private void speak(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "handyhilfe-guide");
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && tts != null) {
            tts.setLanguage(Locale.GERMANY);
            tts.setSpeechRate(0.86f);
        }
    }

    @Override
    public void onInterrupt() {
        if (tts != null) tts.stop();
    }

    @Override
    public void onDestroy() {
        if (receiverRegistered) {
            try { unregisterReceiver(stopReceiver); } catch (Exception ignored) {}
        }
        if (windowManager != null && overlay != null) {
            try { windowManager.removeView(overlay); } catch (Exception ignored) {}
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    private static String normalize(CharSequence value) {
        if (value == null) return "";
        return normalize(value.toString());
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .replace("ß", "ss")
                .trim();
    }

    private static final class Match {
        AccessibilityNodeInfo node;
        int score = 0;
    }
}
