package de.handyhilfe.assistent;

import java.util.Arrays;
import java.util.List;

public final class GuideStep {
    public static final String TYPE_ACTION = "action";
    public static final String TYPE_INPUT = "input";
    public static final String TYPE_SWITCH = "switch";

    public final String id;
    public final String instruction;
    public final String type;
    public final int minChars;
    public final List<String> candidates;

    private GuideStep(String id, String instruction, String type, int minChars, String... candidates) {
        this.id = id;
        this.instruction = instruction;
        this.type = type;
        this.minChars = minChars;
        this.candidates = Arrays.asList(candidates);
    }

    public static GuideStep action(String id, String instruction, String... candidates) {
        return new GuideStep(id, instruction, TYPE_ACTION, 0, candidates);
    }

    public static GuideStep input(String id, String instruction, int minChars, String... candidates) {
        return new GuideStep(id, instruction, TYPE_INPUT, minChars, candidates);
    }

    public static GuideStep toggle(String id, String instruction, String... candidates) {
        return new GuideStep(id, instruction, TYPE_SWITCH, 0, candidates);
    }
}
