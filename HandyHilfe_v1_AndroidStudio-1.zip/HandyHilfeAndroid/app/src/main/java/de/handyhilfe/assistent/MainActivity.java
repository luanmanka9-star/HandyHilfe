package de.handyhilfe.assistent;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements RecognitionListener, TextToSpeech.OnInitListener {
    private static final int REQ_AUDIO = 1001;
    private static final int REQ_CAMERA = 1002;

    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private TextView accessibilityStatus;
    private TextView voiceStatus;
    private boolean pendingTorch = false;
    private boolean torchOn = false;
    private String pendingWorkflow = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        textToSpeech = new TextToSpeech(this, this);
        torchOn = getPreferences(MODE_PRIVATE).getBoolean("torch_on", false);
        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateAccessibilityStatus();
        if (pendingWorkflow != null && isAccessibilityEnabled()) {
            String workflow = pendingWorkflow;
            pendingWorkflow = null;
            getWindow().getDecorView().postDelayed(() -> startWorkflow(workflow), 350);
        }
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(247, 249, 252));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(36));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, matchWrap(0));

        RobotLogoView logo = new RobotLogoView(this);
        header.addView(logo, new LinearLayout.LayoutParams(dp(82), dp(82)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        titleParams.leftMargin = dp(14);
        header.addView(titleBox, titleParams);

        TextView title = text("HandyHilfe", 31, true, Color.rgb(19, 35, 58));
        titleBox.addView(title);
        TextView subtitle = text("Dein Roboter zeigt dir jeden Schritt.", 18, false, Color.rgb(74, 85, 104));
        subtitle.setPadding(0, dp(4), 0, 0);
        titleBox.addView(subtitle);

        root.addView(space(14));

        LinearLayout setupCard = card();
        root.addView(setupCard, cardParams());
        TextView setupTitle = text("1. Roboter aktivieren", 22, true, Color.rgb(19, 35, 58));
        setupCard.addView(setupTitle);
        accessibilityStatus = text("Prüfe Bedienungshilfe …", 18, true, Color.rgb(124, 45, 18));
        accessibilityStatus.setPadding(0, dp(8), 0, dp(10));
        setupCard.addView(accessibilityStatus);
        Button enable = primaryButton("Bedienungshilfe aktivieren");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        setupCard.addView(enable, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)));

        root.addView(space(16));

        LinearLayout voiceCard = new LinearLayout(this);
        voiceCard.setOrientation(LinearLayout.VERTICAL);
        voiceCard.setPadding(dp(18), dp(20), dp(18), dp(20));
        voiceCard.setBackground(round(Color.rgb(19, 35, 58), 22));
        root.addView(voiceCard, cardParams());

        TextView voiceTitle = text("Sag einfach, was du brauchst", 24, true, Color.WHITE);
        voiceCard.addView(voiceTitle);
        TextView examples = text("Zum Beispiel: „Nummer speichern“, „WLAN“, „Foto machen“ oder „Wecker stellen“.", 18, false, Color.rgb(226, 232, 240));
        examples.setPadding(0, dp(8), 0, dp(16));
        voiceCard.addView(examples);

        Button speak = new Button(this);
        speak.setText("SPRICH MIT MIR");
        speak.setTextSize(22);
        speak.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        speak.setTextColor(Color.rgb(19, 35, 58));
        speak.setAllCaps(false);
        speak.setBackground(round(Color.rgb(255, 213, 74), 18));
        speak.setOnClickListener(v -> startListening());
        voiceCard.addView(speak, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(76)));

        voiceStatus = text("Bereit.", 17, true, Color.WHITE);
        voiceStatus.setPadding(0, dp(12), 0, 0);
        voiceCard.addView(voiceStatus);

        root.addView(space(22));
        TextView quick = text("Wichtige Funktionen", 25, true, Color.rgb(19, 35, 58));
        root.addView(quick);
        TextView quickSub = text("Du kannst auch direkt auf eine große Taste tippen.", 17, false, Color.rgb(74, 85, 104));
        quickSub.setPadding(0, dp(4), 0, dp(12));
        root.addView(quickSub);

        root.addView(actionCard("Nummer speichern", "Roboter führt durch Kontakte", () -> startWorkflow(WorkflowSpec.CONTACT)));
        root.addView(actionCard("WLAN", "WLAN-Schalter finden und hervorheben", () -> startWorkflow(WorkflowSpec.WIFI)));
        root.addView(actionCard("Bluetooth", "Bluetooth-Schalter finden", () -> startWorkflow(WorkflowSpec.BLUETOOTH)));
        root.addView(actionCard("Foto machen", "Kamera öffnen und Auslöser zeigen", () -> startWorkflow(WorkflowSpec.CAMERA)));
        root.addView(actionCard("Wecker stellen", "Neuen Wecker Schritt für Schritt", () -> startWorkflow(WorkflowSpec.ALARM)));
        root.addView(actionCard("WhatsApp", "WhatsApp öffnen und Suche zeigen", () -> startWorkflow(WorkflowSpec.WHATSAPP)));
        root.addView(actionCard("SMS schreiben", "Empfänger, Nachricht und Senden zeigen", () -> startWorkflow(WorkflowSpec.SMS)));
        root.addView(actionCard("Taschenlampe", "Direkt ein- oder ausschalten", this::toggleTorch));
        root.addView(actionCard("Lauter", "Medienlautstärke erhöhen", () -> adjustVolume(true)));
        root.addView(actionCard("Leiser", "Medienlautstärke verringern", () -> adjustVolume(false)));

        root.addView(space(18));
        Button stop = secondaryButton("Anleitung stoppen");
        stop.setOnClickListener(v -> {
            AssistantState.stop(this);
            sendBroadcast(new Intent(RobotAccessibilityService.ACTION_STOP_GUIDE).setPackage(getPackageName()));
            speak("Anleitung gestoppt.");
            Toast.makeText(this, "Anleitung gestoppt", Toast.LENGTH_SHORT).show();
        });
        root.addView(stop, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)));

        root.addView(space(14));
        TextView safety = text("Sicher: Der Roboter zeigt und erklärt. Er bestätigt keine Käufe, Passwörter oder Bankvorgänge automatisch.", 16, false, Color.rgb(74, 85, 104));
        safety.setLineSpacing(0, 1.15f);
        root.addView(safety);

        return scroll;
    }

    private View actionCard(String title, String subtitle, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(16), dp(18), dp(16));
        card.setBackground(round(Color.WHITE, 18));
        card.setClickable(true);
        card.setFocusable(true);
        card.setContentDescription(title + ". " + subtitle);
        card.setOnClickListener(v -> action.run());

        TextView t = text(title, 22, true, Color.rgb(19, 35, 58));
        card.addView(t);
        TextView s = text(subtitle, 17, false, Color.rgb(74, 85, 104));
        s.setPadding(0, dp(4), 0, 0);
        card.addView(s);

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(10);
        card.setLayoutParams(p);
        card.setMinimumHeight(dp(78));
        return card;
    }

    private void startWorkflow(String workflow) {
        if (!isAccessibilityEnabled()) {
            pendingWorkflow = workflow;
            speak("Bitte aktiviere zuerst HandyHilfe in der Bedienungshilfe. Danach mache ich automatisch weiter.");
            Toast.makeText(this, "HandyHilfe Roboter einschalten – danach geht es automatisch weiter", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }

        Intent intent = buildWorkflowIntent(workflow);
        if (intent == null) {
            speak("Diese Funktion konnte ich auf diesem Handy nicht öffnen.");
            return;
        }

        AssistantState.start(this, workflow);
        String expectedPackage = resolveExpectedPackage(intent, workflow);
        AssistantState.setExpectedPackage(this, expectedPackage);

        try {
            startActivity(intent);
        } catch (Exception e) {
            AssistantState.stop(this);
            Toast.makeText(this, "Funktion auf diesem Gerät nicht verfügbar", Toast.LENGTH_LONG).show();
            speak("Diese Funktion ist auf diesem Gerät nicht verfügbar.");
        }
    }

    private Intent buildWorkflowIntent(String workflow) {
        switch (workflow) {
            case WorkflowSpec.CONTACT:
                return new Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI);
            case WorkflowSpec.WIFI:
                return new Intent(Settings.ACTION_WIFI_SETTINGS);
            case WorkflowSpec.BLUETOOTH:
                return new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
            case WorkflowSpec.CAMERA:
                return new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            case WorkflowSpec.ALARM:
                return new Intent(AlarmClock.ACTION_SHOW_ALARMS);
            case WorkflowSpec.WHATSAPP:
                return getPackageManager().getLaunchIntentForPackage("com.whatsapp");
            case WorkflowSpec.SMS:
                return new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"));
            default:
                return null;
        }
    }

    private String resolveExpectedPackage(Intent intent, String workflow) {
        if (WorkflowSpec.WHATSAPP.equals(workflow)) return "com.whatsapp";
        ComponentName component = intent.resolveActivity(getPackageManager());
        return component == null ? "" : component.getPackageName();
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        ensureSpeechRecognizer();
        if (speechRecognizer == null) {
            voiceStatus.setText("Spracherkennung ist auf diesem Gerät nicht verfügbar.");
            speak("Spracherkennung ist auf diesem Gerät nicht verfügbar.");
            return;
        }

        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.GERMANY.toLanguageTag());
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, Locale.GERMANY.toLanguageTag());
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Was möchtest du machen?");
        voiceStatus.setText("Ich höre zu …");
        speechRecognizer.startListening(intent);
    }

    private void ensureSpeechRecognizer() {
        if (speechRecognizer != null) return;
        try {
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
            if (speechRecognizer != null) speechRecognizer.setRecognitionListener(this);
        } catch (Exception ignored) {
            speechRecognizer = null;
        }
    }

    private void handleSpokenCommand(String spoken) {
        String n = normalize(spoken);
        voiceStatus.setText("Verstanden: „" + spoken + "“");

        if (containsAny(n, "nummer speichern", "kontakt speichern", "neue nummer", "kontakt hinzufugen")) {
            startWorkflow(WorkflowSpec.CONTACT);
        } else if (containsAny(n, "wlan", "wifi", "wi fi")) {
            startWorkflow(WorkflowSpec.WIFI);
        } else if (n.contains("bluetooth")) {
            startWorkflow(WorkflowSpec.BLUETOOTH);
        } else if (containsAny(n, "foto", "kamera", "bild machen")) {
            startWorkflow(WorkflowSpec.CAMERA);
        } else if (containsAny(n, "wecker", "alarm")) {
            startWorkflow(WorkflowSpec.ALARM);
        } else if (n.contains("whatsapp")) {
            startWorkflow(WorkflowSpec.WHATSAPP);
        } else if (containsAny(n, "sms", "textnachricht", "nachricht schreiben")) {
            startWorkflow(WorkflowSpec.SMS);
        } else if (containsAny(n, "taschenlampe", "licht an", "licht aus")) {
            toggleTorch();
        } else if (containsAny(n, "lauter", "lautstarke hoch")) {
            adjustVolume(true);
        } else if (containsAny(n, "leiser", "lautstarke runter")) {
            adjustVolume(false);
        } else {
            speak("Das habe ich noch nicht verstanden. Du kannst zum Beispiel Nummer speichern, WLAN, Foto machen oder Wecker stellen sagen.");
            voiceStatus.setText("Das kenne ich noch nicht. Bitte noch einmal versuchen.");
        }
    }

    private void adjustVolume(boolean louder) {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        int direction = louder ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
        speak(louder ? "Ich habe die Lautstärke erhöht." : "Ich habe die Lautstärke verringert.");
    }

    private void toggleTorch() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingTorch = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            String selected = null;
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics c = manager.getCameraCharacteristics(id);
                Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) && (facing == null || facing == CameraCharacteristics.LENS_FACING_BACK)) {
                    selected = id;
                    break;
                }
            }
            if (selected == null) {
                speak("Dieses Handy hat keine verfügbare Taschenlampe.");
                return;
            }
            torchOn = !torchOn;
            manager.setTorchMode(selected, torchOn);
            getPreferences(MODE_PRIVATE).edit().putBoolean("torch_on", torchOn).apply();
            speak(torchOn ? "Taschenlampe ist an." : "Taschenlampe ist aus.");
        } catch (CameraAccessException | SecurityException e) {
            Toast.makeText(this, "Taschenlampe konnte nicht geschaltet werden", Toast.LENGTH_LONG).show();
            speak("Die Taschenlampe konnte ich gerade nicht schalten.");
        }
    }

    private void updateAccessibilityStatus() {
        if (accessibilityStatus == null) return;
        if (isAccessibilityEnabled()) {
            accessibilityStatus.setText("Aktiv – der Roboter kann Buttons hervorheben.");
            accessibilityStatus.setTextColor(Color.rgb(22, 101, 52));
        } else {
            accessibilityStatus.setText("Noch nicht aktiv. Einmal einschalten.");
            accessibilityStatus.setTextColor(Color.rgb(154, 52, 18));
        }
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        ComponentName target = new ComponentName(this, RobotAccessibilityService.class);
        String[] components = enabled.split(":");
        for (String flat : components) {
            ComponentName c = ComponentName.unflattenFromString(flat);
            if (c != null && c.equals(target)) return true;
        }
        return false;
    }

    private void speak(String text) {
        if (textToSpeech != null) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "handyhilfe-main");
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && textToSpeech != null) {
            textToSpeech.setLanguage(Locale.GERMANY);
            textToSpeech.setSpeechRate(0.88f);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_AUDIO && granted) {
            startListening();
        } else if (requestCode == REQ_CAMERA && granted && pendingTorch) {
            pendingTorch = false;
            toggleTorch();
        } else if (!granted) {
            Toast.makeText(this, "Berechtigung wurde nicht erteilt", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onReadyForSpeech(Bundle params) { voiceStatus.setText("Ich höre zu …"); }
    @Override public void onBeginningOfSpeech() { voiceStatus.setText("Ich höre dich …"); }
    @Override public void onRmsChanged(float rmsdB) {}
    @Override public void onBufferReceived(byte[] buffer) {}
    @Override public void onEndOfSpeech() { voiceStatus.setText("Ich verarbeite das …"); }
    @Override public void onEvent(int eventType, Bundle params) {}

    @Override
    public void onError(int error) {
        String msg;
        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            msg = "Ich habe nichts verstanden. Tippe und sprich bitte noch einmal.";
        } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            msg = "Mikrofon-Berechtigung fehlt.";
        } else {
            msg = "Spracherkennung ist gerade nicht verfügbar. Bitte noch einmal versuchen.";
        }
        voiceStatus.setText(msg);
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) handleSpokenCommand(matches.get(0));
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null && !matches.isEmpty()) voiceStatus.setText("„" + matches.get(0) + "“");
    }

    @Override
    protected void onDestroy() {
        if (speechRecognizer != null) speechRecognizer.destroy();
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }

    private static String normalize(String value) {
        if (value == null) return "";
        String s = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
        return s.replace("ß", "ss");
    }

    private static boolean containsAny(String value, String... needles) {
        for (String n : needles) if (value.contains(n)) return true;
        return false;
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(round(Color.WHITE, 20));
        return card;
    }

    private LinearLayout.LayoutParams cardParams() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private Button primaryButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(19);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(round(Color.rgb(18, 97, 160), 16));
        return b;
    }

    private Button secondaryButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(19);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.rgb(19, 35, 58));
        b.setAllCaps(false);
        b.setBackground(round(Color.rgb(226, 232, 240), 16));
        return b;
    }

    private TextView text(String value, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setLineSpacing(0, 1.05f);
        return t;
    }

    private View space(int heightDp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(heightDp)));
        return v;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private LinearLayout.LayoutParams matchWrap(int bottomMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(bottomMargin);
        return p;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
