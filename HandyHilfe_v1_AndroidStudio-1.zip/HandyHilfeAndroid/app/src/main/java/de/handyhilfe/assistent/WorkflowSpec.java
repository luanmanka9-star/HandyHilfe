package de.handyhilfe.assistent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class WorkflowSpec {
    public static final String CONTACT = "contact";
    public static final String WIFI = "wifi";
    public static final String BLUETOOTH = "bluetooth";
    public static final String CAMERA = "camera";
    public static final String ALARM = "alarm";
    public static final String WHATSAPP = "whatsapp";
    public static final String SMS = "sms";

    private WorkflowSpec() {}

    public static String title(String workflow) {
        switch (workflow) {
            case CONTACT: return "Nummer speichern";
            case WIFI: return "WLAN";
            case BLUETOOTH: return "Bluetooth";
            case CAMERA: return "Foto machen";
            case ALARM: return "Wecker stellen";
            case WHATSAPP: return "WhatsApp";
            case SMS: return "SMS schreiben";
            default: return "HandyHilfe";
        }
    }

    public static List<GuideStep> steps(String workflow) {
        List<GuideStep> s = new ArrayList<>();
        switch (workflow) {
            case CONTACT:
                s.add(GuideStep.action("contact_add",
                        "Tippe auf „Kontakt hinzufügen“ oder auf das Plus-Zeichen.",
                        "kontakt hinzufügen", "kontakt erstellen", "neuen kontakt erstellen",
                        "neuer kontakt", "add contact", "create contact", "new contact", "+"));
                s.add(GuideStep.input("contact_name",
                        "Gib hier den Namen der Person ein.", 2,
                        "vorname", "name", "first name", "given name"));
                s.add(GuideStep.input("contact_phone",
                        "Gib hier die Telefonnummer ein.", 3,
                        "telefonnummer", "telefon", "handy", "mobil", "phone", "mobile"));
                s.add(GuideStep.action("contact_save",
                        "Zum Schluss tippe auf „Speichern“.",
                        "speichern", "fertig", "save", "done"));
                break;

            case WIFI:
                s.add(GuideStep.toggle("wifi_toggle",
                        "Hier kannst du WLAN ein- oder ausschalten.",
                        "wlan verwenden", "wi-fi verwenden", "use wi-fi", "wlan", "wi-fi", "wifi"));
                break;

            case BLUETOOTH:
                s.add(GuideStep.toggle("bluetooth_toggle",
                        "Hier kannst du Bluetooth ein- oder ausschalten.",
                        "bluetooth verwenden", "use bluetooth", "bluetooth"));
                break;

            case CAMERA:
                s.add(GuideStep.action("camera_shutter",
                        "Tippe hier, um das Foto aufzunehmen.",
                        "foto aufnehmen", "auslöser", "aufnahme", "take photo", "shutter", "capture"));
                break;

            case ALARM:
                s.add(GuideStep.action("alarm_add",
                        "Tippe hier, um einen neuen Wecker hinzuzufügen.",
                        "wecker hinzufügen", "alarm hinzufügen", "neuer wecker", "add alarm", "new alarm", "+"));
                s.add(GuideStep.action("alarm_done",
                        "Wenn die Uhrzeit stimmt, bestätige hier.",
                        "speichern", "fertig", "ok", "save", "done"));
                break;

            case WHATSAPP:
                s.add(GuideStep.action("wa_search",
                        "Tippe auf die Suche, um eine Person zu finden.",
                        "suchen", "suche", "search"));
                s.add(GuideStep.input("wa_search_text",
                        "Schreibe jetzt den Namen der Person. Danach tippe auf den passenden Kontakt.", 2,
                        "suchen", "suche", "search"));
                break;

            case SMS:
                s.add(GuideStep.input("sms_to",
                        "Gib hier den Namen oder die Telefonnummer des Empfängers ein.", 2,
                        "empfänger", "an", "recipient", "to"));
                s.add(GuideStep.input("sms_message",
                        "Schreibe hier deine Nachricht.", 2,
                        "nachricht", "textnachricht", "message", "enter message"));
                s.add(GuideStep.action("sms_send",
                        "Wenn alles stimmt, tippe hier auf „Senden“.",
                        "senden", "send"));
                break;
        }
        return Collections.unmodifiableList(s);
    }

    public static GuideStep current(String workflow, int step) {
        List<GuideStep> steps = steps(workflow);
        if (step < 0 || step >= steps.size()) return null;
        return steps.get(step);
    }
}
