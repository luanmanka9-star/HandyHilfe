package de.handyhilfe.assistent;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

public class GuideOverlayView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private RectF target;
    private String instruction = "";
    private String stepLabel = "";
    private float robotX = -1f;
    private float robotY = -1f;
    private float desiredRobotX = -1f;
    private float desiredRobotY = -1f;
    private boolean visible = false;
    private boolean success = false;

    public GuideOverlayView(Context context) {
        super(context);
        setWillNotDraw(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
    }

    public void showTarget(Rect rect, String instruction, String stepLabel) {
        if (rect == null || rect.width() <= 0 || rect.height() <= 0) return;
        this.success = false;
        this.visible = true;
        this.target = new RectF(rect);
        this.instruction = instruction == null ? "" : instruction;
        this.stepLabel = stepLabel == null ? "" : stepLabel;

        float margin = dp(16);
        float robotSize = dp(64);
        float cx = target.centerX();
        float cy = target.centerY();
        float nextX = cx > getWidth() / 2f ? target.left - robotSize * 0.7f : target.right + robotSize * 0.7f;
        float nextY = target.top - robotSize * 0.25f;
        if (getWidth() > 0) nextX = clamp(nextX, margin + robotSize / 2f, getWidth() - margin - robotSize / 2f);
        if (getHeight() > 0) nextY = clamp(nextY, dp(150), getHeight() - margin - robotSize / 2f);
        animateRobotTo(nextX, nextY);
        invalidate();
    }

    public void showSuccess(String message) {
        this.success = true;
        this.visible = true;
        this.target = null;
        this.stepLabel = "Geschafft";
        this.instruction = message == null ? "Geschafft!" : message;
        this.robotX = getWidth() / 2f;
        this.robotY = getHeight() / 2f + dp(40);
        invalidate();
    }

    public void hideGuide() {
        visible = false;
        target = null;
        invalidate();
    }

    private void animateRobotTo(float x, float y) {
        desiredRobotX = x;
        desiredRobotY = y;
        if (robotX < 0 || robotY < 0) {
            robotX = getWidth() > 0 ? getWidth() - dp(52) : x;
            robotY = getHeight() > 0 ? getHeight() - dp(120) : y;
        }
        final float sx = robotX;
        final float sy = robotY;
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(520);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(a -> {
            float f = (float) a.getAnimatedValue();
            robotX = sx + (desiredRobotX - sx) * f;
            robotY = sy + (desiredRobotY - sy) * f;
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!visible) return;

        if (success) {
            paint.setColor(0xB319233A);
            canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
            drawBubble(canvas, true);
            drawRobot(canvas, robotX, robotY, dp(82));
            return;
        }

        if (target != null) {
            float pad = dp(9);
            RectF hole = new RectF(target.left - pad, target.top - pad, target.right + pad, target.bottom + pad);
            hole.left = Math.max(0, hole.left);
            hole.top = Math.max(0, hole.top);
            hole.right = Math.min(getWidth(), hole.right);
            hole.bottom = Math.min(getHeight(), hole.bottom);

            paint.setColor(0x8F000000);
            canvas.drawRect(0, 0, getWidth(), hole.top, paint);
            canvas.drawRect(0, hole.bottom, getWidth(), getHeight(), paint);
            canvas.drawRect(0, hole.top, hole.left, hole.bottom, paint);
            canvas.drawRect(hole.right, hole.top, getWidth(), hole.bottom, paint);

            float pulse = 0.72f + 0.28f * (float) Math.sin(SystemClock.uptimeMillis() / 180.0);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(dp(7));
            paint.setColor(Color.argb((int) (210 + 45 * pulse), 255, 213, 74));
            canvas.drawRoundRect(hole, dp(14), dp(14), paint);
            paint.setStrokeWidth(dp(2));
            paint.setColor(Color.WHITE);
            canvas.drawRoundRect(new RectF(hole.left + dp(4), hole.top + dp(4), hole.right - dp(4), hole.bottom - dp(4)), dp(10), dp(10), paint);
            paint.setStyle(Paint.Style.FILL);

            paint.setColor(Color.WHITE);
            paint.setStrokeWidth(dp(6));
            canvas.drawLine(robotX, robotY, hole.centerX(), hole.centerY(), paint);
            paint.setColor(Color.rgb(255, 213, 74));
            paint.setStrokeWidth(dp(3));
            canvas.drawLine(robotX, robotY, hole.centerX(), hole.centerY(), paint);

            drawRobot(canvas, robotX, robotY, dp(68));
            drawBubble(canvas, false);
            postInvalidateDelayed(45);
        }
    }

    private void drawBubble(Canvas canvas, boolean centered) {
        float margin = dp(16);
        float bubbleWidth = getWidth() - margin * 2;
        float top = centered ? dp(120) : dp(20);
        float bubbleHeight = centered ? dp(150) : dp(124);
        RectF bubble = new RectF(margin, top, margin + bubbleWidth, top + bubbleHeight);

        paint.setColor(Color.WHITE);
        paint.setShadowLayer(dp(8), 0, dp(3), 0x55000000);
        setLayerType(LAYER_TYPE_SOFTWARE, paint);
        canvas.drawRoundRect(bubble, dp(20), dp(20), paint);
        paint.clearShadowLayer();

        paint.setColor(Color.rgb(19, 35, 58));
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(sp(15));
        canvas.drawText(stepLabel, bubble.left + dp(18), bubble.top + dp(28), paint);

        textPaint.setColor(Color.rgb(23, 32, 42));
        textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        textPaint.setTextSize(sp(centered ? 25 : 21));
        int textWidth = (int) (bubbleWidth - dp(36));
        StaticLayout layout = StaticLayout.Builder.obtain(instruction, 0, instruction.length(), textPaint, textWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setIncludePad(false)
                .setLineSpacing(0, 1.05f)
                .setMaxLines(centered ? 3 : 3)
                .build();
        canvas.save();
        canvas.translate(bubble.left + dp(18), bubble.top + dp(42));
        layout.draw(canvas);
        canvas.restore();
    }

    private void drawRobot(Canvas canvas, float cx, float cy, float size) {
        float r = size / 2f;
        paint.setColor(Color.rgb(19, 35, 58));
        canvas.drawCircle(cx, cy, r, paint);

        paint.setColor(Color.rgb(255, 213, 74));
        paint.setStrokeWidth(size * 0.055f);
        canvas.drawLine(cx, cy - r * 0.72f, cx, cy - r * 1.02f, paint);
        canvas.drawCircle(cx, cy - r * 1.08f, size * 0.045f, paint);

        paint.setColor(Color.WHITE);
        RectF face = new RectF(cx - r * 0.65f, cy - r * 0.45f, cx + r * 0.65f, cy + r * 0.47f);
        canvas.drawRoundRect(face, size * 0.08f, size * 0.08f, paint);

        paint.setColor(Color.rgb(18, 97, 160));
        canvas.drawCircle(cx - r * 0.28f, cy - r * 0.06f, size * 0.055f, paint);
        canvas.drawCircle(cx + r * 0.28f, cy - r * 0.06f, size * 0.055f, paint);

        paint.setColor(Color.rgb(19, 35, 58));
        RectF mouth = new RectF(cx - r * 0.28f, cy + r * 0.20f, cx + r * 0.28f, cy + r * 0.27f);
        canvas.drawRoundRect(mouth, dp(2), dp(2), paint);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private float sp(float value) {
        return value * getResources().getDisplayMetrics().scaledDensity;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
