package de.handyhilfe.assistent;

import android.content.Context;
import android.content.SharedPreferences;

public final class AssistantState {
    private static final String PREFS = "handyhilfe_state";
    private static final String KEY_ACTIVE = "active";
    private static final String KEY_WORKFLOW = "workflow";
    private static final String KEY_STEP = "step";
    private static final String KEY_PACKAGE = "expected_package";

    private AssistantState() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void start(Context context, String workflow) {
        prefs(context).edit()
                .putBoolean(KEY_ACTIVE, true)
                .putString(KEY_WORKFLOW, workflow)
                .putInt(KEY_STEP, 0)
                .putString(KEY_PACKAGE, "")
                .apply();
    }

    public static boolean isActive(Context context) {
        return prefs(context).getBoolean(KEY_ACTIVE, false);
    }

    public static String getWorkflow(Context context) {
        return prefs(context).getString(KEY_WORKFLOW, "");
    }

    public static int getStep(Context context) {
        return prefs(context).getInt(KEY_STEP, 0);
    }

    public static void setStep(Context context, int step) {
        prefs(context).edit().putInt(KEY_STEP, Math.max(0, step)).apply();
    }

    public static void advance(Context context) {
        setStep(context, getStep(context) + 1);
    }

    public static void setExpectedPackage(Context context, String packageName) {
        prefs(context).edit().putString(KEY_PACKAGE, packageName == null ? "" : packageName).apply();
    }

    public static String getExpectedPackage(Context context) {
        return prefs(context).getString(KEY_PACKAGE, "");
    }

    public static void stop(Context context) {
        prefs(context).edit()
                .putBoolean(KEY_ACTIVE, false)
                .putString(KEY_WORKFLOW, "")
                .putInt(KEY_STEP, 0)
                .putString(KEY_PACKAGE, "")
                .apply();
    }
}
