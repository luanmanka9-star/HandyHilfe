package de.handyhilfe.assistent;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class RobotLogoView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public RobotLogoView(Context context) {
        super(context);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        float size = Math.min(w, h);
        float cx = w / 2f;
        float cy = h / 2f;

        paint.setColor(Color.rgb(19, 35, 58));
        canvas.drawCircle(cx, cy, size * 0.47f, paint);

        paint.setColor(Color.rgb(255, 213, 74));
        paint.setStrokeWidth(size * 0.05f);
        canvas.drawLine(cx, cy - size * 0.34f, cx, cy - size * 0.22f, paint);
        canvas.drawCircle(cx, cy - size * 0.37f, size * 0.045f, paint);

        paint.setColor(Color.WHITE);
        RectF face = new RectF(cx - size * 0.30f, cy - size * 0.20f,
                cx + size * 0.30f, cy + size * 0.24f);
        canvas.drawRoundRect(face, size * 0.08f, size * 0.08f, paint);

        paint.setColor(Color.rgb(18, 97, 160));
        canvas.drawCircle(cx - size * 0.13f, cy - size * 0.02f, size * 0.055f, paint);
        canvas.drawCircle(cx + size * 0.13f, cy - size * 0.02f, size * 0.055f, paint);

        paint.setColor(Color.rgb(19, 35, 58));
        RectF mouth = new RectF(cx - size * 0.13f, cy + size * 0.10f,
                cx + size * 0.13f, cy + size * 0.14f);
        canvas.drawRoundRect(mouth, size * 0.02f, size * 0.02f, paint);
    }
}
