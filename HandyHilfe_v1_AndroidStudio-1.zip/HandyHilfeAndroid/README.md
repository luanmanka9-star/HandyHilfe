# HandyHilfe – Roboter-Assistent (Android)

HandyHilfe ist ein seniorenfreundlicher Android-Assistent. Die App hört einen Wunsch oder startet ihn über große Tasten. Ein Accessibility-Overlay bewegt einen kleinen Roboter zum passenden Bedienelement, dunkelt unwichtige Bereiche ab, umrahmt das Ziel und erklärt den nächsten Schritt in großer Schrift und per Sprache.

## Enthaltene Funktionen v1.0

- Kontakt / Telefonnummer speichern
- WLAN öffnen und den wichtigen Schalter hervorheben
- Bluetooth öffnen und hervorheben
- Kamera öffnen und den Auslöser zeigen
- Wecker öffnen und „Wecker hinzufügen“ zeigen
- WhatsApp öffnen und die Suche zeigen
- SMS öffnen und Empfänger, Nachricht und Senden führen
- Taschenlampe direkt ein-/ausschalten
- Lautstärke lauter/leiser
- Sprachsteuerung mit On-Device-Spracherkennung, falls Android sie anbietet
- Große Schrift, große Touch-Flächen, hoher Kontrast
- Der Roboter klickt keine sensiblen Bestätigungen automatisch

## Installation / Build

1. Projekt in Android Studio Quail 4 oder neuer öffnen.
2. Android SDK 36 installieren, falls Android Studio danach fragt.
3. `Build > Build APK(s)` auswählen.
4. Die Debug-APK liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.
5. APK auf das Android-Handy übertragen und installieren.
6. Beim ersten Start Mikrofon erlauben.
7. In HandyHilfe auf **Bedienungshilfe aktivieren** tippen und **HandyHilfe Roboter** einschalten.

## Automatischer GitHub-Build

Im Projekt liegt `.github/workflows/build-apk.yml`. Nach dem Hochladen in ein GitHub-Repository kann `Build HandyHilfe APK` unter **Actions** ausgeführt werden. Die fertige APK erscheint als Build-Artefakt `HandyHilfe-APK`.

## Warum Accessibility?

Die App nutzt den Android-Accessibility-Service ausschließlich für die aktive Schritt-für-Schritt-Hilfe. Sie liest die sichtbaren Bedienelemente, ermittelt deren Bildschirmposition und zeichnet darüber ein nicht-blockierendes Overlay. Der Nutzer tippt weiterhin selbst.

## Hinweis zur Gerätevielfalt

Hersteller können Bezeichnungen und Oberflächen verändern. Die Erkennung verwendet deshalb mehrere deutsche und englische Begriffe sowie Eigenschaften der Accessibility-Nodes. Für Serienreife sollten die Abläufe anschließend auf Samsung, Google Pixel, Xiaomi/Redmi, Oppo/OnePlus und Motorola getestet und je Hersteller ergänzt werden.
